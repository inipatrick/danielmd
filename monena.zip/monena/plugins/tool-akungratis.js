let handler = async m => m.reply(`
「 AKUN GRATIS 」

• MINECRAFT (XBOX)

1. Username : nikitasf@gmail.com
Password : tasfel13

2. Username : icudxiii@gmail.com
Password : Spencer13

3. Username : jackall04@gmail.com
Password : Foxtail19

4. Username : zaitsev2020@gmail.com
Password : sniperm4n

5. Username : joker2019@gmail.com
Password : legendversion2007

6. Username : coronaman1@gmail.com
Password : virusboosted1

7. Username : externable@gmail.com
Password : remote12

8. Username : drstrange01@hotmail.com
Password : 3569851426

9. Username : radiostanciq225@gmail.com
Password : stenli123

10. Username : majorking5@gmail.com
Password : 55major55

• FREE FIRE

1. Email : alyunus06@gmail.com
Password : @0607199022
Handphone : 087783381296

2. Email : mukulverma49@gmail.com
Password : mucool14
Handphone : +919802811414

3. Email : amitsharma.07821@gmail.com
Password : Anjeeta_sharma
Handphone : +918145777657

4. Email : syahrulmutafifin@gmail.com
Password : 1234fatimah
Handphone : 089626702848

5. Email : marcelrikudo@yahoo.com
Password : marcel01
Handphone : 081366483303

6. Email : maddy_333@gmail.com
Password : shonyadholu
Handphone : 09822259111

7. Email : wawanfold7@gmail.com
Password : Indra fq
Handphone : +6282251122608

8. Email : giangoda477@gmail.com
Password : Password
Handphone : 8718021268

9. Email : tsharma@gmail.com
Password : hanuman001
Handphone : 9891497114

10. Email : Adb19@gmail.com
Password : 124356abhi
Handphone : 9891098921

• MOBILE LEGENDS

1. Email Google : ejak@gmail.com
Password Google : 1234567
Nomor Hp : 082281080512
Email Facebook: 4ndika01
Password Facebook : ysfifoy

2. Email Google : kadexandika@gmail.com
Password Google : 040498ka$
Nomor Hp : 082281080512
Email Facebook: 4ndika01
Password Facebook : 040498ka$

3. Email Google : arakoswara330@gmail.com
Password Google : 123tasik123
Nomor Hp : 085603266121
Email Facebook: Kebiw
Password Facebook : tasik123

4. Email Google : ramamelodic@yahoo.co.id
Password Google : modolsoto
Nomor Hp : 0894343
Email Facebook: ramadhan
Password Facebook : modolsoto

5. Email Google : arifzainudin@gmail.com
Password Google : arif123456
Nomor Hp : 081222889877
Email Facebook: arifzainudin@gmail.com
Password Facebook : 123456789

6. Email Google : guncorojati@gmail.com
Password Google : jatijati
Nomor Hp : 085875631052
Email Facebook: 085647818863
Password Facebook : paerhosokyess

7. Email Google : defidefle@gmail.com
Password Google : 01juli1994
Nomor Hp : 085280327955
Email Facebook: Ulhyyulii@ymail.com
Password Facebook : 01juli1994

8. Email Google : aaby79709@gmail.com
Password Google : mchc malang
Nomor Hp : 082241848845
Email Facebook: 08123560040
Password Facebook : albimafitra

9. Email Google : abicok@gmail.com
Password Google : abicokasu
Nomor Hp : 081239874408
Email Facebook: Abiasu@gmail.com
Password Facebook : abiasucok

10. Email Google : jcxdamha@gmail.com
Password Google : damha123
Nomor Hp : 08593912224
Email Facebook: 083834700739
Password Facebook : damha12

• PUBG

1. Email: Adwilired20012@caraqu.com
Kata sandi: terminantor29

2. Email: Breracia@gmail.com
Kata sandi: coolkidbres

3. Email: YbaliwythFAV@gmail.com
Kata sandi: superiorman_

4. Email: DrunythGenius@gmail.com
Kata sandi: 12345682

5. Email: DrunythPUBG202@gmail.com
Kata sandi: 21021985

6. Email: Onoret@hotmail.com
Kata sandi: onogeniztta12

7. Email: Helidianewacc@gmail.com
Kata sandi: felixiloveyou

8. Email: Adwilired20012@gmail.com
Kata sandi: terminantor29

9. Email: Breracia@gmail.com
Kata sandi: coolkidbres

10. Email: YbaliwythFAV@gmail.com
Kata sandi: superiorman_

「 ᴹᴿ᭄ King Of Bear ×፝֟͜×  」
`.trim()) // Tambah sendiri kalo mau
handler.help = ['akungratis','freeaccount']
handler.tags = ['tools']
handler.command = /^(akungratis|freeaccount)$/i

handler.limit = true

export default handler 
